package com.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSysApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentManagementSysApplication.class, args);
    }
}
