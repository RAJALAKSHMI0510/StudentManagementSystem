package com.edu.service;

import java.util.List;
import java.util.Optional;

import com.edu.dao.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student saveStudent(Student student);

	String updateStudent(Long id, Student studentDetails);

	String deleteStudent(Long id);

	Optional<Student> getStudentById(Long id);

}
