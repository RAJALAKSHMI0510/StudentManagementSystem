package com.edu.service;

import java.util.List;
import java.util.Optional;

import com.edu.dao.Course;

public interface CourseService {

	List<Course> getAllCourses();

	Course saveCourse(Course course);

	String updateCourse(Long id, Course courseDetails);

	String deleteCourse(Long id);

	Optional<Course> getCourseById(Long id);

}
