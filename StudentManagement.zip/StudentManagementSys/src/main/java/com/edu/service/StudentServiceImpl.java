package com.edu.service;

import com.edu.dao.Student; 
import com.edu.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public String updateStudent(Long id, Student studentDetails) {
        Optional<Student> optionalStudent = studentRepository.findById(id);
        if (optionalStudent.isPresent()) {
            Student student = optionalStudent.get();
            student.setName(studentDetails.getName());
            student.setEmail(studentDetails.getEmail());
            student.setPhone(studentDetails.getPhone());
            student.setUsername(studentDetails.getUsername());
            student.setPassword(studentDetails.getPassword());
            student.setCourse(studentDetails.getCourse());
            studentRepository.save(student);
            return "Student updated successfully!";
        } else {
            return "Student ID not found!";
        }
    }

    public String deleteStudent(Long id) {
        if (studentRepository.existsById(id)) {
            studentRepository.deleteById(id);
            return "Student deleted successfully!";
        } else {
            return "Student ID not found!";
        }
    }
}
